import {useEffect, useState} from 'react';
import { getCharactersAll2 } from '../api/getCharacter';

export const useFetchImagen = (finBusqueda) => {

    const [state, setState] = useState ({
        data : [],
        loading: true
    });

    useEffect(() => {
        getCharactersAll2(finBusqueda).then(imagen => {
            setState({
                data : imagen,
                loading : false
            })
        })
    }, [finBusqueda])

    return state;
}

/*
export const useFetchImagen = (finBusqueda) => {

    const [state, setState] = useState ({
        data : [],
        loading: true
    });

    useEffect(() => {
        getCharactersAll2(finBusqueda).then(imagen => {
            setState({
                data : imagen,
                loading : false
            })
        })
    }, [finBusqueda])

    return state;
}
*/