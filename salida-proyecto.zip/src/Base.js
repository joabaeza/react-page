import {BrowserRouter, Switch, Route} from 'react-router-dom'
import Home from './components/Home'
import Menu from './components/Menu';
import Location from './components/Location'

function Base() {
  return (
    <BrowserRouter>        
    <Menu/>
    <div  className="container-mio"
     >    
     
      <Switch>
        <Route exact path="/">
          <Home/>
        </Route> 
        <Route exact path="/location">
          <Location/>
        </Route> 
      </Switch>
    </div>    
    </BrowserRouter>
  );
}

export default Base;
