import React from 'react'
import { Card as CA, Button, Modal } from 'react-bootstrap';
import { useState } from 'react';

const Card = ({ id, name, status,origin, location_name, image }) => {

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);  
  return (
    <>
      <section>
        <CA key={id} style={{ width: '18rem' }} className="card mt-5" >
          <div className='personaje-header'>
            <div className='estado'>
              <span className={status}></span>
              <h4>{status}</h4>
            </div>
          </div>
          <CA.Img variant="top" src={image} />
          <CA.Body>
            <CA.Title >{name}</CA.Title>
            <Button variant="primary" onClick={handleShow}>Detalle</Button>
          </CA.Body>
        </CA>
      </section>
      <Modal show={show} onHide={handleClose} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="container">
            <div className="row">
              <div className="col-4">
                <CA style={{ width: '15rem' }}>
                  <CA.Img variant="top" src={image} />
                  
                </CA>
              </div>
              <div className="col-8">
                <CA style={{ width: '30rem' }}>
                  <CA.Body>
                    <table class="table">
                      <thead>
                        <tr>                          
                          <th scope="col">Detail</th>
                          <th scope="col">Answer</th>                          
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Name</td>
                          <td>{name}</td>
                        </tr>
                        <tr>
                          <td>Status</td>
                          <td>{status}</td>
                        </tr>

                        <tr>
                          <td>Locacion</td>
                          <td>{location_name}</td>
                        </tr>
                        
                        <tr>
                          <td>Status</td>
                          <td>{status}</td>
                        </tr>

                        <tr>
                          <td>Origin</td>
                          <td>{origin}</td>
                        </tr>
                      </tbody>
                    </table>
                  </CA.Body>
                </CA>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>Cerrar</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}


export default Card
