import React,{ useState } from 'react'
import Cardlist from './Cardlist';
const Home = () => {   
        const [images] = useState(['']);        
        return (
            <div className="container">
                <div className="row">
                
                {
                  images.map ( img => (<Cardlist key={images}  />))
                }
                </div>
            </div>
        )
    
    
}
export default Home
