import React from 'react'
import { Navbar,Container,Nav} from 'react-bootstrap'
import { NavLink } from 'react-router-dom'

const Menu = () => {
    return (
        <>
 <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand >[Rick and Morty]</Navbar.Brand>  
  
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="me-auto">
      <NavLink className="nav-link" to={"/"}>Personajes</NavLink>
      <NavLink className="nav-link" to={"/location"} >Locaciones</NavLink>     
    </Nav>    
  </Navbar.Collapse>
  </Container>
</Navbar>
</>
    )
}

export default Menu