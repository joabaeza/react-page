import React from 'react'
import { Modal } from 'react-bootstrap'

function ModalDetalle() {
    return (
        <>
            <Modal show={show} onHide={handleClose}  size="lg">
      <Modal.Header closeButton>
        <Modal.Title>{name}</Modal.Title>
      </Modal.Header>
      <Modal.Body> 
            <div className="container">
              <div className="row">
                <div className="col-4">
            <CA style={{ width: '15rem' }}>
              <CA.Img variant="top"src={image} />
              <CA.Body>
              <CA.Title>Card Title</CA.Title>
              <CA.Text>
                Some quick example text to build on the card title and make up the bulk of
              the card's content.
                </CA.Text>                
              </CA.Body>
            </CA>
            </div>
            <div className="col-8">
            <CA style={{ width: '30rem' }}>              
              <CA.Body>              
              <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Name detail</th>
      <th scope="col">Detail</th>     
    </tr>
  </thead>
  <tbody>
    <tr>
      
      <td>Name</td>
      <td>{name}</td>
      
    </tr>
    <tr>
      
      <td>Status</td>
      <td>{status}</td>
      
    </tr>
    <tr>
      
      <td>Locacion</td>
      <td>{location_name}</td>
      
      
    </tr>
  </tbody>
</table>
              </CA.Body>
            </CA>
            </div>
            </div>
            </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>Close</Button>        
      </Modal.Footer>
    </Modal>
            </>
    )
}

export default ModalDetalle












