
import {useFetchImagen} from '../hooks/useFetchImagen';
import Card from './Card'

const  Cardlist  = () => {
      const {data:images} = useFetchImagen()      
        return (
            <>
            <h1  style={{}} className="text-center joa">PERSONAJES RICK AND MORTY</h1>
            <h2 className="text-center">By Joaquin Baeza Octubre 2021</h2>
            {
                images.map(img => (
                    <div className="col-3" key={img.id}>
                    <Card {...img}/>
                    </div>
                ))
            }
            
            </>
        )
    }


export default Cardlist
