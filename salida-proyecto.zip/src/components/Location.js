import React, { useState, useEffect } from 'react'
import { locations } from '../api/getCharacter';
import {Table} from 'react-bootstrap'
const Location = () => {
    const [locas, setUsers] = useState([]);
    useEffect(() => {
        locations().then(locas => setUsers(locas)
        )
    }, [])
    console.log(locas)
    return (
        <div className="container-dos">
             <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>N°</th> 
                                    <th>Name : </th>
                                    <th>Type : </th>
                                    <th>Dimension :</th>                                    
                                </tr>
                            </thead>
             <tbody>
                       
            {
                locas.map(locas=> (
                                <tr key={locas.id}>
                                    <td >{locas.id}</td>
                                    <td>{locas.name}</td>
                                    <td>{locas.type}</td>
                                    <td>{locas.dimension}</td>
                                </tr>                              
                          

                    
                ))
            }
              </tbody>
                        </Table>
        </div>
    )
}

export default Location
