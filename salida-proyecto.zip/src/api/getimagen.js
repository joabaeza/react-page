export const getImgs = async () => {
    const URL = `https://rickandmortyapi.com/api/character`;

    const resp = await fetch(URL);
    const { results } = await resp.json();
    const imgs = results.map( img => {
        return {
            id   : img.id,
            name: img.name,
            url  : img.image,   
            location_name : img.location.name,                                
           
        }
    })    
    return imgs;
}

export const getImgId = async(id) => {
    const data = await fetch(`https://rickandmortyapi.com/api/character/${id}`);
    const user = await data.json();
    return user;
}

// export const getImgId = async(id) => {
//     const data = await fetch(`https://rickandmortyapi.com/api/character/${id}`);
//     const { results } = await data.json();
//     const imgs = results.map( img => {
//         return {
//             id   : img.id,
//             name: img.name,
//             url  : img.image
//         }
//     })

//     return imgs;
// }