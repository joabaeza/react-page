//tra solo los datos
export const getCharactersAll2 = async () => {
    const data = await fetch('https://rickandmortyapi.com/api/character');
    const { results } = await data.json();
    const imgs = results.map( result => {
        return{
            id : result.id,
            name : result.name,
            status : result.status,            
            origin : result.origin.name,
            location_name : result.location.name,
            image : result.image,
        }
    })
    return imgs;
}

export const locations = async () => {
    const data = await fetch('https://rickandmortyapi.com/api/location');
    //obtiene solo resultados sin cabecera
    const { results } = await data.json();
    const datos = results.map( result => {
        return{
            id : result.id,
            name : result.name,
            type: result.type,
            dimension : result.dimension
        }
    })
    return datos;
}




